// src/pages/TeamPage.js
import React from 'react';
import PageLayout, { PageHeader } from '../Components/common/PageLayout';
import TeamSection from '../Components/TeamSection';

const TeamPage = () => {
  return (
    <PageLayout>
      <PageHeader>
        <h1>Our Team</h1>
        <p>Meet the talented artists who bring your vision to life</p>
      </PageHeader>
      <TeamSection showFullBio={true} /> {/* Display all team members with full bios */}
    </PageLayout>
  );
};

export default TeamPage;