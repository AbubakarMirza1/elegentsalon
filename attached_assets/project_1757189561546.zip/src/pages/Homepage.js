// src/pages/HomePage.js
import React from 'react';
import Hero from '../Components/Hero';
import AboutSection from '../Components/AboutSection';
import ServicesSection from '../Components/ServicesSection';
import TeamSection from '../Components/TeamSection';

const HomePage = () => {
  return (
    <>
      <Hero />
      <AboutSection />
      <ServicesSection limit={3} /> {/* Show only 3 services on home page */}
      <TeamSection limit={3} /> {/* Show only 3 team members on home page */}
    </>
  );
};

export default HomePage;