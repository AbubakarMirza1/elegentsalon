// src/pages/CareersPage.js
import React from 'react';
import styled from 'styled-components';
import PageLayout, { PageHeader } from '../Components/common/PageLayout';
import CareerForm from '../Components/CareerForm';
import theme from '../styles/theme';

const CareersContent = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: ${theme.spacing.xl};
  align-items: center;
  margin-bottom: ${theme.spacing.lg};

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
    text-align: center;
  }
`;

const CareersText = styled.div`
  h2 {
    font-size: 2.5rem;
    margin-bottom: ${theme.spacing.md};
    color: ${theme.colors.primary};
    font-weight: 300;
  }

  p {
    font-size: 1.1rem;
    line-height: 1.8;
    color: ${theme.colors.textSecondary};
    margin-bottom: ${theme.spacing.md};
    font-family: ${theme.fonts.sansSerif};
  }

  h3 {
    margin-top: ${theme.spacing.md};
    margin-bottom: ${theme.spacing.sm};
    color: ${theme.colors.accent};
  }

  ul {
    font-family: ${theme.fonts.sansSerif};
    color: ${theme.colors.textSecondary};
    line-height: 1.8;
    list-style-position: inside;
    margin-left: ${theme.spacing.md}; /* Add some indent for readability */
    padding-left: 0; /* Override default padding */
  }

  ul li {
      margin-bottom: ${theme.spacing.xs};
  }
`;

const CareersImage = styled.div`
  position: relative;

  img {
    width: 100%;
    height: 400px;
    object-fit: cover;
    border-radius: ${theme.borderRadius};
    box-shadow: ${theme.shadows.large};
  }
`;

const CareersPage = () => {
  return (
    <PageLayout>
      <PageHeader>
        <h1>Join Our Team</h1>
        <p>Build your career with Essential Hair Studio</p>
      </PageHeader>
      
      <CareersContent>
        <CareersText>
          <h2>Why Work With Us?</h2>
          <p>At Essential Hair Studio, we believe in fostering talent and creating an environment where creativity thrives. We offer competitive compensation, ongoing education opportunities, and a supportive team atmosphere.</p>
          
          <h3 style={{ marginTop: theme.spacing.md, marginBottom: theme.spacing.sm, color: theme.colors.accent }}>Benefits & Perks</h3>
          <ul>
            <li>Competitive salary plus commission</li>
            <li>Flexible scheduling options</li>
            <li>Continuing education reimbursement</li>
            <li>Product discounts</li>
            <li>Modern, well-equipped workspace</li>
            <li>Collaborative team environment</li>
          </ul>
        </CareersText>
        <CareersImage>
          <img src="https://images.pexels.com/photos/3992856/pexels-photo-3992856.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Our team at work" />
        </CareersImage>
      </CareersContent>
      
      {/* The CareerForm is placed outside the CareersContent grid to take full width */}
      <CareerForm />
    </PageLayout>
  );
};

export default CareersPage;