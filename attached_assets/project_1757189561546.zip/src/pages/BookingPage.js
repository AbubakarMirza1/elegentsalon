// src/pages/BookingPage.js
import React from 'react';
import PageLayout, { PageHeader } from '../Components/common/PageLayout';
import BookingForm from '../Components/BookingForm';

const BookingPage = () => {
  return (
    <PageLayout>
      <PageHeader>
        <h1>Book Your Appointment</h1>
        <p>Schedule your visit with our professional team</p>
      </PageHeader>
      <BookingForm />
    </PageLayout>
  );
};

export default BookingPage;