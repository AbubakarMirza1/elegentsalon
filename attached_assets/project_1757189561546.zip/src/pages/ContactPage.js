// src/pages/ContactPage.js
import React from 'react';
import styled from 'styled-components';
import PageLayout, { PageHeader } from '../Components/common/PageLayout';
import ContactForm from '../Components/ContactForm';
import theme from '../styles/theme';

const ContactContent = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: ${theme.spacing.xl};

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
  }
`;

const ContactInfo = styled.div`
  h3 {
    font-size: 1.5rem;
    margin-bottom: ${theme.spacing.md};
    color: ${theme.colors.primary};
  }

  p, address {
    color: ${theme.colors.textSecondary};
    font-family: ${theme.fonts.sansSerif};
    margin-bottom: ${theme.spacing.sm};
    font-style: normal;
  }

  .hours {
    margin-top: ${theme.spacing.md};

    h4 {
      color: ${theme.colors.primary};
      margin-bottom: ${theme.spacing.sm};
    }
  }

  .social-links {
    display: flex;
    gap: ${theme.spacing.sm};
    margin-top: ${theme.spacing.md};

    a {
      display: inline-block;
      width: 40px;
      height: 40px;
      background: ${theme.colors.accent};
      border-radius: 50%;
      text-align: center;
      line-height: 40px;
      color: ${theme.colors.white};
      transition: background 0.3s ease;

      &:hover {
        background: ${theme.colors.darkAccent};
      }
    }
  }

  @media (max-width: 1024px) {
    text-align: center;
  }
`;

const ContactPage = () => {
  return (
    <PageLayout>
      <PageHeader>
        <h1>Contact Us</h1>
        <p>Get in touch to schedule your appointment</p>
      </PageHeader>
      
      <ContactContent>
        <ContactInfo>
          <h3>Visit Our Studio</h3>
          <address>
            123 Main Street<br/>
            Downtown District<br/>
            City, State 12345
          </address>
          
          <h3 style={{ marginTop: theme.spacing.md }}>Get In Touch</h3>
          <p><strong>Phone:</strong> (555) 123-4567</p>
          <p><strong>Email:</strong> hello@essentialhair.com</p>
          
          <div className="hours">
            <h4>Studio Hours</h4>
            <p><strong>Monday - Friday:</strong> 9:00 AM - 7:00 PM</p>
            <p><strong>Saturday:</strong> 9:00 AM - 5:00 PM</p>
            <p><strong>Sunday:</strong> 10:00 AM - 4:00 PM</p>
          </div>
          
          <div className="social-links">
            <a href="#" aria-label="Instagram">📷</a>
            <a href="#" aria-label="Facebook">📘</a>
            <a href="#" aria-label="Twitter">🐦</a>
          </div>
        </ContactInfo>
        
        <ContactForm />
      </ContactContent>
    </PageLayout>
  );
};

export default ContactPage;