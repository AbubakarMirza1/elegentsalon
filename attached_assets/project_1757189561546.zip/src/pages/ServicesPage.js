// src/pages/ServicesPage.js
import React from 'react';
import PageLayout, { PageHeader } from '../Components/common/PageLayout';
import ServicesSection from '../Components/ServicesSection';

const ServicesPage = () => {
  return (
    <PageLayout>
      <PageHeader>
        <h1>Our Services</h1>
        <p>Professional hair care tailored to your needs</p>
      </PageHeader>
      <ServicesSection /> {/* Display all services */}
    </PageLayout>
  );
};

export default ServicesPage;