// src/pages/AboutPage.js
import React from 'react';
import styled from 'styled-components';
import PageLayout, { PageHeader } from '../Components/common/PageLayout';
import theme from '../styles/theme';

const AboutContentGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: ${theme.spacing.xl};
  align-items: center;

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
    text-align: center;
  }
`;

const AboutText = styled.div`
  h2 {
    font-size: 2.5rem;
    margin-bottom: ${theme.spacing.md};
    color: ${theme.colors.primary};
    font-weight: 300;
  }

  p {
    font-size: 1.1rem;
    line-height: 1.8;
    color: ${theme.colors.textSecondary};
    margin-bottom: ${theme.spacing.md};
    font-family: ${theme.fonts.sansSerif};
  }

  h3 {
    margin-top: ${theme.spacing.md};
    margin-bottom: ${theme.spacing.sm};
    color: ${theme.colors.accent};
  }

  ul {
    font-family: ${theme.fonts.sansSerif};
    color: ${theme.colors.textSecondary};
    line-height: 1.8;
    list-style-position: inside;
  }
`;

const AboutImage = styled.div`
  position: relative;

  img {
    width: 100%;
    height: 400px;
    object-fit: cover;
    border-radius: ${theme.borderRadius};
    box-shadow: ${theme.shadows.large};
  }
`;

const AboutPage = () => {
  return (
    <PageLayout>
      <PageHeader>
        <h1>About Us</h1>
        <p>Discover the story behind Essential Hair Studio</p>
      </PageHeader>
      
      <AboutContentGrid>
        <AboutText>
          <h2>Our Philosophy</h2>
          <p>At Essential Hair Studio, we believe that great hair is the foundation of confidence. Our philosophy centers around understanding each client's unique style, lifestyle, and hair goals to create looks that are not only beautiful but also manageable and sustainable.</p>
          
          <p>We are committed to using only the finest products that promote hair health while delivering exceptional results. Our team stays current with the latest techniques and trends through continuous education and training.</p>

          <h3>What Sets Us Apart</h3>
          <ul>
            <li>Personalized consultations for every client</li>
            <li>Sustainable and eco-friendly products</li>
            <li>Ongoing education and advanced techniques</li>
            <li>Comfortable, relaxing salon environment</li>
            <li>Commitment to hair health and integrity</li>
          </ul>
        </AboutText>
        <AboutImage>
          <img src="https://images.pexels.com/photos/3992850/pexels-photo-3992850.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Our salon" />
        </AboutImage>
      </AboutContentGrid>
    </PageLayout>
  );
};

export default AboutPage;