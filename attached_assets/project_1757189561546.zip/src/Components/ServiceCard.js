// src/components/ServiceCard.js
import React from 'react';
import styled from 'styled-components';
import theme from '../styles/theme';

const ServiceCardContainer = styled.div`
  background: ${theme.colors.white};
  padding: ${theme.spacing.lg};
  border-radius: ${theme.borderRadius};
  box-shadow: ${theme.shadows.medium};
  text-align: center;
  transition: transform 0.3s ease;

  &:hover {
    transform: translateY(-5px);
  }

  img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    border-radius: ${theme.borderRadius};
    margin-bottom: ${theme.spacing.sm};
  }

  h3 {
    font-size: 1.5rem;
    margin-bottom: ${theme.spacing.sm};
    color: ${theme.colors.primary};
  }

  p {
    color: ${theme.colors.textSecondary};
    font-family: ${theme.fonts.sansSerif};
    margin-bottom: ${theme.spacing.sm};
  }

  .price {
    font-size: 1.3rem;
    color: ${theme.colors.accent};
    font-weight: bold;
  }
`;

const ServiceCard = ({ image, title, description, price }) => {
  return (
    <ServiceCardContainer>
      <img src={image} alt={title} />
      <h3>{title}</h3>
      <p>{description}</p>
      <div className="price">{price}</div>
    </ServiceCardContainer>
  );
};

export default ServiceCard;