// src/components/TeamCard.js
import React from 'react';
import styled from 'styled-components';
import theme from '../styles/theme';

const TeamCardContainer = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius};
  overflow: hidden;
  box-shadow: ${theme.shadows.medium};
  transition: transform 0.3s ease;

  &:hover {
    transform: translateY(-5px);
  }

  img {
    width: 100%;
    height: 300px;
    object-fit: cover;
  }
`;

const TeamInfo = styled.div`
  padding: ${theme.spacing.md};
  text-align: center;

  h3 {
    font-size: 1.3rem;
    margin-bottom: ${theme.spacing.xs};
    color: ${theme.colors.primary};
  }

  .role {
    color: ${theme.colors.accent};
    font-family: ${theme.fonts.sansSerif};
    margin-bottom: ${theme.spacing.sm};
  }

  p {
    color: ${theme.colors.textSecondary};
    font-family: ${theme.fonts.sansSerif};
    font-size: 0.9rem;
    line-height: 1.6;
  }
`;

const TeamCard = ({ image, name, role, bio }) => {
  return (
    <TeamCardContainer>
      <img src={image} alt={name} />
      <TeamInfo>
        <h3>{name}</h3>
        <p className="role">{role}</p>
        <p>{bio}</p>
      </TeamInfo>
    </TeamCardContainer>
  );
};

export default TeamCard;