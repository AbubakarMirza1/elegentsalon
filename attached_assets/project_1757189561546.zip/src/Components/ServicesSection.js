// src/components/ServicesSection.js
import React from 'react';
import styled from 'styled-components';
import theme from '../styles/theme';
import ServiceCard from './ServiceCard';

const ServicesSectionContainer = styled.section`
  padding: ${theme.spacing.xl} 0;
`;

const SectionTitle = styled.h2`
  text-align: center;
  font-size: 2.5rem;
  margin-bottom: ${theme.spacing.xl};
  color: ${theme.colors.primary};
  font-weight: 300;
`;

const ServicesGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: ${theme.spacing.lg};

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

const ServicesSection = ({ limit }) => {
  const servicesData = [
    {
      image: "https://images.pexels.com/photos/3992865/pexels-photo-3992865.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      title: "Hair Cut & Styling",
      description: "Precision cuts tailored to your face shape and lifestyle",
      price: "From $65"
    },
    {
      image: "https://images.pexels.com/photos/3993449/pexels-photo-3993449.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      title: "Color & Highlights",
      description: "Expert coloring using premium, hair-safe products",
      price: "From $95"
    },
    {
      image: "https://images.pexels.com/photos/3992850/pexels-photo-3992850.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      title: "Deep Treatment",
      description: "Nourishing treatments to restore hair health",
      price: "From $45"
    },
    {
      image: "https://images.pexels.com/photos/3992876/pexels-photo-3992876.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      title: "Special Event Styling",
      description: "Updos, formal styles, and special occasion hair for weddings, parties, and events.",
      price: "$75 - $125"
    },
    {
      image: "https://images.pexels.com/photos/3992856/pexels-photo-3992856.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      title: "Hair Extensions",
      description: "Clip-in, tape-in, and sewn-in extensions using 100% human hair for length and volume.",
      price: "$200 - $600"
    },
    {
      image: "https://images.pexels.com/photos/3992865/pexels-photo-3992865.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      title: "Style Consultation",
      description: "Professional consultation to discuss your hair goals, lifestyle, and maintenance preferences.",
      price: "Free with Service"
    }
  ];

  const displayedServices = limit ? servicesData.slice(0, limit) : servicesData;

  return (
    <ServicesSectionContainer>
      <div className="container">
        <SectionTitle>Our Services</SectionTitle>
        <ServicesGrid>
          {displayedServices.map((service, index) => (
            <ServiceCard key={index} {...service} />
          ))}
        </ServicesGrid>
      </div>
    </ServicesSectionContainer>
  );
};

export default ServicesSection;