// src/pages/common/PageLayout.js
import React from 'react';
import styled from 'styled-components';
import theme from '../../styles/theme';

const PageContentWrapper = styled.div`
  margin-top: 100px; /* Height of the fixed header + some spacing */
  padding: ${theme.spacing.xl} 0;
`;

export const PageHeader = styled.div`
  text-align: center;
  margin-bottom: ${theme.spacing.xl};

  h1 {
    font-size: 3rem;
    color: ${theme.colors.primary};
    font-weight: 300;
    margin-bottom: ${theme.spacing.sm};
  }

  p {
    font-size: 1.2rem;
    color: ${theme.colors.textSecondary};
    font-family: ${theme.fonts.sansSerif};
  }
`;

const PageLayout = ({ children }) => {
  return (
    <PageContentWrapper>
      <div className="container">
        {children}
      </div>
    </PageContentWrapper>
  );
};

export default PageLayout;