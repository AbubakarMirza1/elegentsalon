// src/components/common/Buttons.js
import styled from 'styled-components';
import theme from '../../styles/theme';

export const Button = styled.button`
  padding: 0.7rem 1.5rem;
  border-radius: 4px;
  font-family: ${theme.fonts.sansSerif};
  font-weight: 500;
  transition: all 0.3s ease;
  text-decoration: none;
  display: inline-block;
  text-transform: uppercase;
  letter-spacing: 1px;
  cursor: pointer;
`;

export const PrimaryButton = styled(Button)`
  background: ${theme.colors.accent};
  color: ${theme.colors.white};

  &:hover {
    background: ${theme.colors.darkAccent};
    transform: translateY(-2px);
  }
`;

export const SecondaryButton = styled(Button)`
  background: transparent;
  color: ${theme.colors.white};
  border: 2px solid ${theme.colors.white};

  &:hover {
    background: ${theme.colors.white};
    color: ${theme.colors.primary};
  }
`;

export const DarkButton = styled(Button)`
  background: ${theme.colors.primary};
  color: ${theme.colors.white};

  &:hover {
    background: ${theme.colors.accent};
    transform: translateY(-2px);
  }
`;