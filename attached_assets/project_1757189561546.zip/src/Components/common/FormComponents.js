// src/components/common/FormComponents.js
import styled from 'styled-components';
import theme from '../../styles/theme';
import { PrimaryButton } from './button';

export const FormContainer = styled.div`
  max-width: ${({ maxWidth }) => maxWidth || '600px'};
  margin: 0 auto;
  background: ${theme.colors.white};
  padding: ${theme.spacing.xl};
  border-radius: ${theme.borderRadius};
  box-shadow: ${theme.shadows.large};
`;

export const FormGroup = styled.div`
  margin-bottom: ${theme.spacing.md};

  label {
    display: block;
    margin-bottom: ${theme.spacing.xs};
    color: ${theme.colors.primary};
    font-family: ${theme.fonts.sansSerif};
    font-weight: 500;
  }

  input,
  select,
  textarea {
    width: 100%;
    padding: 0.8rem;
    border: 2px solid #eee;
    border-radius: 4px;
    font-family: ${theme.fonts.sansSerif};
    transition: border-color 0.3s ease;

    &:focus {
      outline: none;
      border-color: ${theme.colors.accent};
    }
  }

  textarea {
    resize: vertical;
    min-height: 120px;
  }
`;

export const FormSubmit = styled.div`
  text-align: center;
  margin-top: ${theme.spacing.md};
`;

export const FormTitle = styled.h3`
  margin-bottom: ${theme.spacing.sm};
  text-align: center;
  color: ${theme.colors.primary};
`;

export const SubmitButton = styled(PrimaryButton)`
  padding: 1rem 2rem;
  font-size: 1rem;
`;