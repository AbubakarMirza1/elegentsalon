// src/components/Header.js
import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import styled from 'styled-components';
import theme from '../styles/theme';
import { DarkButton } from './common/button';

const HeaderContainer = styled.header`
  background: ${theme.colors.white};
  padding: ${theme.spacing.sm} 0;
  box-shadow: ${theme.shadows.light};
  position: fixed;
  width: 100%;
  top: 0;
  z-index: 1000;
`;

const Nav = styled.nav`
  display: flex;
  justify-content: space-between;
  align-items: center;
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 ${theme.spacing.sm};
`;

const Logo = styled(Link)`
  font-size: 1.8rem;
  font-weight: bold;
  color: ${theme.colors.primary};
  text-decoration: none;
`;

const NavLinks = styled.ul`
  display: flex;
  list-style: none;
  gap: ${theme.spacing.md};

  @media (max-width: 768px) {
    display: ${({ isOpen }) => (isOpen ? 'flex' : 'none')};
    flex-direction: column;
    position: absolute;
    top: 100%;
    left: 0;
    width: 100%;
    background: ${theme.colors.white};
    box-shadow: ${theme.shadows.light};
    padding: ${theme.spacing.sm} 0;
    align-items: center;
  }
`;

const NavItem = styled.li``;

const NavLinkStyled = styled(NavLink)`
  text-decoration: none;
  color: ${theme.colors.textPrimary};
  font-weight: 500;
  transition: color 0.3s ease;
  font-family: ${theme.fonts.sansSerif};
  padding: ${theme.spacing.xs} 0;

  &:hover,
  &.active {
    color: ${theme.colors.accent};
  }
`;

const MobileMenuButton = styled.button`
  display: none;
  background: none;
  border: none;
  font-size: 1.5rem;
  cursor: pointer;

  @media (max-width: 768px) {
    display: block;
  }
`;

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <HeaderContainer>
      <Nav>
        <Logo to="/">Essential Hair Studio</Logo>
        <NavLinks isOpen={menuOpen}>
          <NavItem>
            <NavLinkStyled to="/" onClick={() => setMenuOpen(false)}>
              Home
            </NavLinkStyled>
          </NavItem>
          <NavItem>
            <NavLinkStyled to="/about" onClick={() => setMenuOpen(false)}>
              About
            </NavLinkStyled>
          </NavItem>
          <NavItem>
            <NavLinkStyled to="/services" onClick={() => setMenuOpen(false)}>
              Services
            </NavLinkStyled>
          </NavItem>
          <NavItem>
            <NavLinkStyled to="/team" onClick={() => setMenuOpen(false)}>
              Team
            </NavLinkStyled>
          </NavItem>
          <NavItem>
            <NavLinkStyled to="/contact" onClick={() => setMenuOpen(false)}>
              Contact
            </NavLinkStyled>
          </NavItem>
          <NavItem>
            <NavLinkStyled to="/careers" onClick={() => setMenuOpen(false)}>
              Careers
            </NavLinkStyled>
          </NavItem>
        </NavLinks>
        <Link to="/booking">
          <DarkButton as="a">Book Appointment</DarkButton>
        </Link>
        <MobileMenuButton onClick={() => setMenuOpen(!menuOpen)}>
          ☰
        </MobileMenuButton>
      </Nav>
    </HeaderContainer>
  );
};

export default Header;