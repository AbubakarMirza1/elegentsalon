// src/components/ContactForm.js
import React, { useState } from 'react';
import { FormContainer, FormGroup, FormSubmit, FormTitle, SubmitButton } from './common/FormComponents';

const ContactForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Contact form submitted:', formData);
    alert('Thank you for your message! We\'ll get back to you soon.');
    setFormData({
      name: '',
      email: '',
      phone: '',
      subject: '',
      message: '',
    });
  };

  return (
    <FormContainer>
      <FormTitle>Send us a Message</FormTitle>
      <form onSubmit={handleSubmit}>
        <FormGroup>
          <label htmlFor="name">Name</label>
          <input type="text" id="name" name="name" value={formData.name} onChange={handleChange} required />
        </FormGroup>

        <FormGroup>
          <label htmlFor="email">Email</label>
          <input type="email" id="email" name="email" value={formData.email} onChange={handleChange} required />
        </FormGroup>

        <FormGroup>
          <label htmlFor="phone">Phone</label>
          <input type="tel" id="phone" name="phone" value={formData.phone} onChange={handleChange} />
        </FormGroup>

        <FormGroup>
          <label htmlFor="subject">Subject</label>
          <select id="subject" name="subject" value={formData.subject} onChange={handleChange} required>
            <option value="">Select a subject</option>
            <option value="appointment">Appointment Inquiry</option>
            <option value="services">Service Questions</option>
            <option value="complaint">Complaint</option>
            <option value="compliment">Compliment</option>
            <option value="other">Other</option>
          </select>
        </FormGroup>

        <FormGroup>
          <label htmlFor="message">Message</label>
          <textarea id="message" name="message" value={formData.message} onChange={handleChange} required></textarea>
        </FormGroup>

        <FormSubmit>
          <SubmitButton type="submit">Send Message</SubmitButton>
        </FormSubmit>
      </form>
    </FormContainer>
  );
};

export default ContactForm;