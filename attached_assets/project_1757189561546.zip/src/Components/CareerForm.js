// src/components/CareerForm.js
import React, { useState } from 'react';
import styled from 'styled-components';
import { FormContainer, FormGroup, FormSubmit, FormTitle, SubmitButton } from './common/FormComponents';
import theme from '../styles/theme';

const CareerFormContainer = styled(FormContainer)`
  max-width: 600px; /* Adjust as needed */
`;

const CareerForm = () => {
  const [formData, setFormData] = useState({
    applicantName: '',
    applicantEmail: '',
    applicantPhone: '',
    position: '',
    experience: '',
    availability: '',
    license: '',
    coverLetter: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Career application submitted:', formData);
    alert('Thank you for your application! We\'ll review it and contact you if we\'d like to schedule an interview.');
    setFormData({
      applicantName: '',
      applicantEmail: '',
      applicantPhone: '',
      position: '',
      experience: '',
      availability: '',
      license: '',
      coverLetter: '',
    });
  };

  return (
    <CareerFormContainer>
      <FormTitle>Apply Now</FormTitle>
      <form onSubmit={handleSubmit}>
        <FormGroup>
          <label htmlFor="applicantName">Full Name</label>
          <input type="text" id="applicantName" name="applicantName" value={formData.applicantName} onChange={handleChange} required />
        </FormGroup>

        <FormGroup>
          <label htmlFor="applicantEmail">Email</label>
          <input type="email" id="applicantEmail" name="applicantEmail" value={formData.applicantEmail} onChange={handleChange} required />
        </FormGroup>

        <FormGroup>
          <label htmlFor="applicantPhone">Phone Number</label>
          <input type="tel" id="applicantPhone" name="applicantPhone" value={formData.applicantPhone} onChange={handleChange} required />
        </FormGroup>

        <FormGroup>
          <label htmlFor="position">Position Applied For</label>
          <select id="position" name="position" value={formData.position} onChange={handleChange} required>
            <option value="">Select a position</option>
            <option value="stylist">Hair Stylist</option>
            <option value="colorist">Color Specialist</option>
            <option value="assistant">Salon Assistant</option>
            <option value="receptionist">Receptionist</option>
            <option value="manager">Assistant Manager</option>
          </select>
        </FormGroup>

        <FormGroup>
          <label htmlFor="experience">Years of Experience</label>
          <select id="experience" name="experience" value={formData.experience} onChange={handleChange} required>
            <option value="">Select experience level</option>
            <option value="0-1">0-1 years</option>
            <option value="2-5">2-5 years</option>
            <option value="6-10">6-10 years</option>
            <option value="10+">10+ years</option>
          </select>
        </FormGroup>

        <FormGroup>
          <label htmlFor="availability">Availability</label>
          <select id="availability" name="availability" value={formData.availability} onChange={handleChange} required>
            <option value="">Select availability</option>
            <option value="full-time">Full-time</option>
            <option value="part-time">Part-time</option>
            <option value="weekends">Weekends only</option>
            <option value="flexible">Flexible</option>
          </select>
        </FormGroup>

        <FormGroup>
          <label htmlFor="license">License Information</label>
          <textarea id="license" name="license" value={formData.license} onChange={handleChange} placeholder="Please provide your cosmetology license number and state of issue..." required></textarea>
        </FormGroup>

        <FormGroup>
          <label htmlFor="coverLetter">Why do you want to work at Essential Hair Studio?</label>
          <textarea id="coverLetter" name="coverLetter" value={formData.coverLetter} onChange={handleChange} placeholder="Tell us about yourself and why you'd be a great addition to our team..." required></textarea>
        </FormGroup>

        <FormSubmit>
          <SubmitButton type="submit">Submit Application</SubmitButton>
        </FormSubmit>
      </form>
    </CareerFormContainer>
  );
};

export default CareerForm;