// src/components/BookingForm.js
import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { FormContainer, FormGroup, FormSubmit, FormTitle, SubmitButton } from './common/FormComponents';

const BookingFormContainer = styled(FormContainer)`
  max-width: 800px;
`;

const BookingForm = () => {
  const [formData, setFormData] = useState({
    clientName: '',
    clientEmail: '',
    clientPhone: '',
    service: '',
    stylist: '',
    date: '',
    time: '',
    notes: '',
  });

  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    setFormData((prevData) => ({ ...prevData, date: today }));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Booking form submitted:', formData);
    alert('Your appointment request has been submitted! We\'ll contact you within 24 hours to confirm.');
    setFormData({
      clientName: '',
      clientEmail: '',
      clientPhone: '',
      service: '',
      stylist: '',
      date: new Date().toISOString().split('T')[0], // Reset to today's date
      time: '',
      notes: '',
    });
  };

  return (
    <BookingFormContainer>
      <FormTitle>Book Your Appointment</FormTitle>
      <form onSubmit={handleSubmit}>
        <FormGroup>
          <label htmlFor="clientName">Full Name</label>
          <input type="text" id="clientName" name="clientName" value={formData.clientName} onChange={handleChange} required />
        </FormGroup>

        <FormGroup>
          <label htmlFor="clientEmail">Email</label>
          <input type="email" id="clientEmail" name="clientEmail" value={formData.clientEmail} onChange={handleChange} required />
        </FormGroup>

        <FormGroup>
          <label htmlFor="clientPhone">Phone Number</label>
          <input type="tel" id="clientPhone" name="clientPhone" value={formData.clientPhone} onChange={handleChange} required />
        </FormGroup>

        <FormGroup>
          <label htmlFor="service">Service</label>
          <select id="service" name="service" value={formData.service} onChange={handleChange} required>
            <option value="">Select a service</option>
            <option value="cut">Haircut & Style ($65-$95)</option>
            <option value="color">Color Service ($95-$250)</option>
            <option value="treatment">Hair Treatment ($45-$150)</option>
            <option value="styling">Special Event Styling ($75-$125)</option>
            <option value="extensions">Hair Extensions ($200-$600)</option>
            <option value="consultation">Style Consultation (Free)</option>
          </select>
        </FormGroup>

        <FormGroup>
          <label htmlFor="stylist">Preferred Stylist</label>
          <select id="stylist" name="stylist" value={formData.stylist} onChange={handleChange}>
            <option value="">No preference</option>
            <option value="sarah">Sarah Johnson - Senior Stylist</option>
            <option value="mike">Mike Chen - Color Specialist</option>
            <option value="emma">Emma Davis - Hair Health Specialist</option>
            <option value="lisa">Lisa Rodriguez - Senior Stylist</option>
          </select>
        </FormGroup>

        <FormGroup>
          <label htmlFor="date">Preferred Date</label>
          <input type="date" id="date" name="date" value={formData.date} onChange={handleChange} min={new Date().toISOString().split('T')[0]} required />
        </FormGroup>

        <FormGroup>
          <label htmlFor="time">Preferred Time</label>
          <select id="time" name="time" value={formData.time} onChange={handleChange} required>
            <option value="">Select a time</option>
            <option value="09:00">9:00 AM</option>
            <option value="10:00">10:00 AM</option>
            <option value="11:00">11:00 AM</option>
            <option value="12:00">12:00 PM</option>
            <option value="13:00">1:00 PM</option>
            <option value="14:00">2:00 PM</option>
            <option value="15:00">3:00 PM</option>
            <option value="16:00">4:00 PM</option>
            <option value="17:00">5:00 PM</option>
            <option value="18:00">6:00 PM</option>
          </select>
        </FormGroup>

        <FormGroup>
          <label htmlFor="notes">Special Requests or Notes</label>
          <textarea id="notes" name="notes" value={formData.notes} onChange={handleChange} placeholder="Please include any specific requests, allergies, or additional information..."></textarea>
        </FormGroup>

        <FormSubmit>
          <SubmitButton type="submit">Book Appointment</SubmitButton>
        </FormSubmit>
      </form>
    </BookingFormContainer>
  );
};

export default BookingForm;