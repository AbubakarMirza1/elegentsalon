// src/components/TeamSection.js
import React from 'react';
import styled from 'styled-components';
import theme from '../styles/theme';
import TeamCard from './TeamCard';

const TeamSectionContainer = styled.section`
  padding: ${theme.spacing.xl} 0;
  background: ${theme.colors.secondary};
`;

export const SectionTitle = styled.h2` // Exporting for use in other pages
  text-align: center;
  font-size: 2.5rem;
  margin-bottom: ${theme.spacing.xl};
  color: ${theme.colors.primary};
  font-weight: 300;
`;

const TeamGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: ${theme.spacing.lg};

  @media (max-width: 768px) {
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  }
`;

const TeamSection = ({ limit, showFullBio = false }) => {
  const teamMembers = [
    {
      image: "https://images.pexels.com/photos/3992876/pexels-photo-3992876.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      name: "Sarah Johnson",
      role: "Senior Stylist & Owner",
      bio: "Sarah founded Essential Hair Studio with a vision to create a space where artistry meets wellness. With over 15 years in the industry, she specializes in precision cuts, natural color techniques, and creating personalized looks that enhance each client's individual beauty. Sarah is certified in multiple advanced cutting techniques and continues her education through international workshops."
    },
    {
      image: "https://images.pexels.com/photos/3992856/pexels-photo-3992856.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      name: "Mike Chen",
      role: "Master Color Specialist",
      bio: "Mike is our resident color genius, known for his artistic approach to hair coloring. He specializes in balayage, creative color transformations, and color corrections. With 12 years of experience and training from top colorists worldwide, Mike has an eye for creating dimensional, natural-looking color that complements skin tone and personal style."
    },
    {
      image: "https://images.pexels.com/photos/3992865/pexels-photo-3992865.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      name: "Emma Davis",
      role: "Hair Health Specialist",
      bio: "Emma brings a holistic approach to hair care, focusing on hair health and scalp wellness. She specializes in restorative treatments, keratin services, and working with chemically damaged or problematic hair. Emma's gentle approach and extensive knowledge of hair chemistry help clients achieve their healthiest hair ever."
    },
    {
      image: "https://images.pexels.com/photos/3992850/pexels-photo-3992850.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      name: "Lisa Rodriguez",
      role: "Senior Stylist",
      bio: "Lisa is known for her versatility and ability to create both classic and contemporary looks. She excels at bridal styling, special event hair, and working with diverse hair textures. With 10 years of experience, Lisa's warm personality and attention to detail make every client feel pampered and beautiful."
    }
  ];

  const displayedTeam = limit ? teamMembers.slice(0, limit) : teamMembers;

  return (
    <TeamSectionContainer>
      <div className="container">
        <SectionTitle>Meet Our Artists</SectionTitle>
        <TeamGrid>
          {displayedTeam.map((member, index) => (
            <TeamCard
              key={index}
              image={member.image}
              name={member.name}
              role={member.role}
              bio={showFullBio ? member.bio : member.bio.substring(0, 100) + '...'} // Truncate bio if not showFullBio
            />
          ))}
        </TeamGrid>
      </div>
    </TeamSectionContainer>
  );
};

export default TeamSection;