// src/components/AboutSection.js
import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import theme from '../styles/theme';
import { PrimaryButton } from './common/button';

const AboutSectionContainer = styled.section`
  padding: ${theme.spacing.xl} 0;
  background: ${theme.colors.secondary};
`;

const AboutContent = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: ${theme.spacing.xl};
  align-items: center;

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
    text-align: center;
  }
`;

const AboutText = styled.div`
  h2 {
    font-size: 2.5rem;
    margin-bottom: ${theme.spacing.md};
    color: ${theme.colors.primary};
    font-weight: 300;
  }

  p {
    font-size: 1.1rem;
    line-height: 1.8;
    color: ${theme.colors.textSecondary};
    margin-bottom: ${theme.spacing.md};
    font-family: ${theme.fonts.sansSerif};
  }
`;

const AboutImage = styled.div`
  position: relative;

  img {
    width: 100%;
    height: 400px;
    object-fit: cover;
    border-radius: ${theme.borderRadius};
    box-shadow: ${theme.shadows.large};
  }
`;

const AboutSection = () => {
  return (
    <AboutSectionContainer>
      <div className="container">
        <AboutContent>
          <AboutText>
            <h2>A Great Hairstyle is the Best Accessory</h2>
            <p>We specialise in modern cuts and colour, with an emphasis on the long-term condition of your hair. Our team of experienced stylists use only premium, sustainable products that nourish and protect your hair.</p>
            <p>Located in the heart of the city, we provide a luxurious experience where you can relax and emerge looking and feeling your absolute best.</p>
            <Link to="/about">
              <PrimaryButton as="a">Learn More</PrimaryButton>
            </Link>
          </AboutText>
          <AboutImage>
            <img src="https://images.pexels.com/photos/3992876/pexels-photo-3992876.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Hair styling" />
          </AboutImage>
        </AboutContent>
      </div>
    </AboutSectionContainer>
  );
};

export default AboutSection;