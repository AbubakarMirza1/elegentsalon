// src/components/Hero.js
import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import theme from '../styles/theme';
import { PrimaryButton, SecondaryButton } from './common/button';

const HeroSection = styled.section`
  height: 100vh;
  background: linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.4)), 
              url('https://images.pexels.com/photos/3993449/pexels-photo-3993449.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2') center/cover;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  color: ${theme.colors.white};
  margin-top: 80px; /* Adjust based on header height */
`;

const HeroContent = styled.div`
  h1 {
    font-size: 3.5rem;
    font-weight: 300;
    margin-bottom: ${theme.spacing.sm};
    letter-spacing: 2px;

    @media (max-width: 768px) {
      font-size: 2.5rem;
    }
  }

  p {
    font-size: 1.2rem;
    margin-bottom: ${theme.spacing.md};
    font-family: ${theme.fonts.sansSerif};
    font-weight: 300;
    letter-spacing: 1px;

    @media (max-width: 768px) {
      font-size: 1rem;
    }
  }
`;

const CtaButtons = styled.div`
  display: flex;
  gap: ${theme.spacing.sm};
  justify-content: center;
  flex-wrap: wrap;

  @media (max-width: 768px) {
    flex-direction: column;
    align-items: center;
  }
`;

const Hero = () => {
  return (
    <HeroSection>
      <HeroContent>
        <h1>Look & Feel Your Best</h1>
        <p>Professional Hair Care in the Heart of the City</p>
        <CtaButtons>
          <Link to="/booking">
            <PrimaryButton as="a">Book Appointment</PrimaryButton>
          </Link>
          <Link to="/services">
            <SecondaryButton as="a">View Services</SecondaryButton>
          </Link>
        </CtaButtons>
      </HeroContent>
    </HeroSection>
  );
};

export default Hero;
