// src/styles/theme.js
const theme = {
  colors: {
    primary: '#1a1a1a',
    secondary: '#f8f8f8',
    accent: '#d4af37',
    textPrimary: '#333',
    textSecondary: '#666',
    textLight: '#999',
    white: '#ffffff',
    darkAccent: '#b8941f',
  },
  fonts: {
    serif: "'Georgia', serif",
    sansSerif: "'Arial', sans-serif",
  },
  spacing: {
    xs: '0.5rem',
    sm: '1rem',
    md: '2rem',
    lg: '3rem',
    xl: '4rem',
  },
  shadows: {
    light: '0 2px 10px rgba(0,0,0,0.1)',
    medium: '0 5px 20px rgba(0,0,0,0.1)',
    large: '0 10px 30px rgba(0,0,0,0.1)',
  },
  borderRadius: '8px',
};

export default theme;